/*if we try to implement functions we use this*/
